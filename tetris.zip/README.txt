Tetris – Browser Version (Mobile & Desktop)

How to run locally:
1) Open index.html in your browser.

How to publish on GitHub Pages:
1) Create a public repository (e.g., `tetris`).
2) Upload this `index.html` file.
3) Go to Settings → Pages → set Branch = main, Folder = /(root) → Save.
4) Open: https://USERNAME.github.io/tetris/
